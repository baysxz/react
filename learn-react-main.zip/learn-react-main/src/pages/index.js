export default function Home() {
  return <>react app</>;
}
