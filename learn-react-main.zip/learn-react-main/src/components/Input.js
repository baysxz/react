import styles from "../styles/Input.module.css";
export function Input() {
  return <input placeholder="First name" className={styles.input} />;
}
